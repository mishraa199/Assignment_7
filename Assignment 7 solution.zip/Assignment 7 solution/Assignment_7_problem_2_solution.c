//Write a program to print first N terms of Fibonacci series.
#include <stdio.h>
int main()
{
    int a=-1,b=1,c,num,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=1;i<=num;i++)
    {
        c=a+b;
        a=b;
        b=c;
        printf("%d ",c);
    }
    return 0;
}
