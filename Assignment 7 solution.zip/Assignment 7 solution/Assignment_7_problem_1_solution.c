//Write a program to find the Nth term of the Fibonnaci series.
#include <stdio.h>
int main()
{
    int a=-1,b=1,c=0,num,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=1;i<=num; i++)
    {
      c=a+b;
      a=b;
      b=c;
    }
  printf("%d ",c);
    return 0;
}
