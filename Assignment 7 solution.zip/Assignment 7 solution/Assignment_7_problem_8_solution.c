//Write a program to find next Prime number of a given number.#include <stdio.h>
#include <stdio.h>
int main ()
{
   int a,num,i,flag=0;
   printf("Enter any number: \n");
   scanf("%d",&a);
   for(num=a; 1; num++)
   {
       flag=0;
       for(i=2; i<=a; i++)
       {
           if(num % i==0)
        flag=1;
       }
       if(flag==0)
       {
       printf("%d ",num);
          break;
       }

   }

   return 0;
}
