//Write a program to print all Armstrong numbers under 1000.
#include <stdio.h>
int main()
{
    int num,count,rem,arm;
    for(num=1;num<=1000;num++)
    {
        arm=0;
        count=num;

        while(count!=0)
        {
        rem= count%10;
        arm= (rem*rem*rem)+arm;
        count= count/10;
        }
        if(arm==num)
        printf("%d\n",arm);
    }

    return 0;
}
