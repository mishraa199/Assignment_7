//Write a program to calculate HCF of two numbers.
#include <stdio.h>
int main()
{
    int a,b,H;
    printf("Enter any two numbers :\n");
    scanf("%d%d",&a,&b);
    for(H=a<b?a:b; H>=1; H--)
    {
        if(a%H==0 && b%H==0)
        break;
    }
    printf("%d",H);
    return 0;
}
