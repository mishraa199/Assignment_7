//Write a program to check whether a given number is an Armstrong number or not.

#include <stdio.h>
int main()

{
    int num,count,rem,arm=0;
    printf("Enter any number: \n");
    scanf("%d",&num);
    count=num;
    while(num>0)
    {
        rem= num%10;
        arm= (rem*rem*rem)+arm;
        num= num/10;
    }
    if(arm==count)
        printf("Armstrong number");
    else
        printf("Not Armstrong number");
    return 0;
}
