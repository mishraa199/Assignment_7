//Write a program to check whether a given number is there in the Fibonacci series or not.
#include <stdio.h>
int main()
{
    int a=-1,b=1,c,num,i;
    printf("Enter any number: ");
    scanf("%d",&num);

    for(i=1;i;i++)
    {
        c=a+b;
        a=b;
        b=c;
    if(c==num)
    {
    printf("Number is of Fibonacci series");
    break;
    }
     if(c>num)
     {
         printf("Number is not of Fibonacci series");
         break;
     }
    }

   return 0;
}
