//Write a program to print all Prime numbers between two given numbers.#include <stdio.h>
#include <stdio.h>
int main ()
{
   int a,b,num,i,flag=0;
   printf("Enter any two numbers: \n");
   scanf("%d%d",&a,&b);
   for(num=a; num<=b; num++)
   {
       flag=0;
       for(i=2; i<=num/2; i++)
       {
           if(num % i==0)
        flag=1;
       }
       if(flag==0)
       printf("%d ",num);
   }

   return 0;
}
